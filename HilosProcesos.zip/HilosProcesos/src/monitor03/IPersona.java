package monitor03;

public interface IPersona {

	public void llegar();

	public void saludar();
	
	public int getOrden();
}
